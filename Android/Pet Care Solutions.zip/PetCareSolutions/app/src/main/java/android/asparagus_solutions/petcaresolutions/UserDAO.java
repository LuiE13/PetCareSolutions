package android.asparagus_solutions.petcaresolutions;

import java.sql.*;

public class UserDAO {

    public Connection connection = null;
    private final String DRIVER = "com.mysql.jdbc.Driver";
    private final String DBNAME = "banco";
    private final String URL = "jdbc:mysql://localhost:3306/banco";
    private final String LOGIN = "root";
    private final String SENHA = "";
    private String sql;
    private PreparedStatement statement;
    private ResultSet userInfos;
    private User user;

    public boolean getConnection() {
        try {
            Class.forName(DRIVER);
            connection = DriverManager.getConnection(URL, LOGIN, SENHA);

            return true;
        } catch (ClassNotFoundException e) {

            return false;
        } catch (SQLException e) {

            return false;
        }
    }
    public void close(){
        try {
            connection.close();

        }catch (SQLException erro){

        }
    }


    public boolean signIn(String email,String password){
        try {
            sql = "SELECT * from usuarios WHERE email = ? AND senha = ?";
            statement = connection.prepareStatement(sql);
            statement.setString(1 , email);
            statement.setString(2 , password);
            userInfos = statement.executeQuery();
            userInfos.next();
            user.setUserId(userInfos.getInt(1));
            return true;
        } catch (SQLException e) {
            return false;
        }


    }
}
