package android.asparagus_solutions.petcaresolutions

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import android.app.DatePickerDialog
import android.app.Dialog
import android.widget.DatePicker
import java.util.*



/**
 * A simple [Fragment] subclass.
 * Use the [DataPickerFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class DataPickerFragment(val calback: (result: String) -> Unit) : DialogFragment(), DatePickerDialog.OnDateSetListener {
    // TODO: Rename and change types of parameters
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val c : Calendar = Calendar.getInstance()
        val year : Int = c.get(Calendar.YEAR)
        val month : Int = c.get(Calendar.MONTH)
        val day : Int = c.get(Calendar.DAY_OF_MONTH)
        return DatePickerDialog(requireContext(),this,year,month,day)
    }

    override fun onDateSet(picker: DatePicker?, year: Int, month: Int, day: Int) {
        val monthString = (month+1).toString()
        val dayString = day.toString()
        val yearString = year.toString()
        calback("$dayString / $monthString / $yearString")
    }
}