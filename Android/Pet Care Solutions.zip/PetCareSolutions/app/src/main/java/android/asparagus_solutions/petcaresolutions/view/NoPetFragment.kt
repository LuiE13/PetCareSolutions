package android.asparagus_solutions.petcaresolutions.view

import android.asparagus_solutions.petcaresolutions.view.SignPetActivity
import android.asparagus_solutions.petcaresolutions.databinding.FragmentNoPetBinding
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment

class NoPetFragment : Fragment() {
    private var _binding: FragmentNoPetBinding? = null
    // This property is only valid between onCreateView and
// onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentNoPetBinding.inflate(inflater, container, false)
        val view = binding.root

        binding.petNew.setOnClickListener {
            val intent = Intent(activity, SignPetActivity::class.java)
            startActivity(intent)
        }

        return view
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment PetFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            NoPetFragment().apply {
                arguments = Bundle().apply {
                    putString(android.asparagus_solutions.petcaresolutions.ARG_PARAM1, param1)
                    putString(android.asparagus_solutions.petcaresolutions.ARG_PARAM2, param2)
                }
            }
    }

}