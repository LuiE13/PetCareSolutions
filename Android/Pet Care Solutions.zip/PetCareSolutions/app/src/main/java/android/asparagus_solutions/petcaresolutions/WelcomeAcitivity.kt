package android.asparagus_solutions.petcaresolutions

import android.asparagus_solutions.petcaresolutions.databinding.ActivityWelcomeAcitivityBinding
import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class WelcomeAcitivity : AppCompatActivity() {
    lateinit var binding: ActivityWelcomeAcitivityBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityWelcomeAcitivityBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.entrabtn.setOnClickListener({
            val intent = Intent(this,LoginActivity::class.java)
            startActivity(intent)
        })

        binding.cadastrobtn.setOnClickListener({
            val intent = Intent(this,SignInActivity::class.java)
            startActivity(intent)
        })
    }

}