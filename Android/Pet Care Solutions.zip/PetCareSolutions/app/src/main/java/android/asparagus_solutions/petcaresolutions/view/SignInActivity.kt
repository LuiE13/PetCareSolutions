package android.asparagus_solutions.petcaresolutions.view

import android.asparagus_solutions.petcaresolutions.databinding.ActivitySignInBinding
import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class SignInActivity : AppCompatActivity() {
    lateinit var binding: ActivitySignInBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivitySignInBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.dataInsert.setOnClickListener {
            DataPickerFragment { result ->
                binding.dataInsert.text = result
            }.show(supportFragmentManager,"datePicker")
        }
        binding.login.setOnClickListener {
            //temporario
            val intent = Intent(this, ForgotActivity::class.java)
            startActivity(intent)
        }
    }
}