package android.asparagus_solutions.petcaresolutions.controller;

import android.asparagus_solutions.petcaresolutions.model.User;

import java.util.Collections;
import java.util.List;

public class UserController implements ICrud<User>{
    @Override
    public boolean inserir(User obj) {
        
        return false;
    }

    @Override
    public boolean alterar(User obj) {
        return false;
    }

    @Override
    public boolean deletar(User obj) {
        return false;
    }

    @Override
    public List<User> listar() {
        return Collections.emptyList();
    }
}
