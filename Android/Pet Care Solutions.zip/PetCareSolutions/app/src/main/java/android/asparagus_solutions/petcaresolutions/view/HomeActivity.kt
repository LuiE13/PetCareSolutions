package android.asparagus_solutions.petcaresolutions.view

import android.asparagus_solutions.petcaresolutions.R
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_home)
        //"""fazer""" o cadastro
        supportFragmentManager.beginTransaction().replace(R.id.trocaTela, NoPetFragment()).commit()

    }
    override fun onResume() {
        super.onResume()
        supportFragmentManager.beginTransaction().replace(R.id.trocaTela, PetFragment()).commit()

    }
}