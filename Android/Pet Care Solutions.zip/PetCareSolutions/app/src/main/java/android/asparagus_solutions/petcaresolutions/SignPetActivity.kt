package android.asparagus_solutions.petcaresolutions

import android.asparagus_solutions.petcaresolutions.databinding.ActivitySignPetBinding
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class SignPetActivity : AppCompatActivity() {
    lateinit var binding: ActivitySignPetBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivitySignPetBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.dataInsert.setOnClickListener {
            DataPickerFragment { result -> binding.dataInsert.text = result
            }.show(supportFragmentManager,"datePicker")
        }
        binding.dogito.setOnClickListener {
            binding.dogito.setBackgroundResource(R.drawable.border_purple)
            binding.catito.setBackgroundResource(R.drawable.border_ball)
        }
        binding.catito.setOnClickListener {
            binding.dogito.setBackgroundResource(R.drawable.border_ball)
            binding.catito.setBackgroundResource(R.drawable.border_purple)

        }

    }
}