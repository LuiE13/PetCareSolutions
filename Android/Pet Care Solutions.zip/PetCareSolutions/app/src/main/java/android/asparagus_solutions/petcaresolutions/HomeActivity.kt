package android.asparagus_solutions.petcaresolutions

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_home)
        //"""fazer""" o cadastro

    }
    override fun onResume() {
        super.onResume()
        supportFragmentManager.beginTransaction().replace(R.id.trocaTela, NoPetFragment()).commit()

    }
}