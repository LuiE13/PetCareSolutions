package android.asparagus_solutions.petcaresolutions.view

import android.asparagus_solutions.petcaresolutions.view.HomeActivity
import android.asparagus_solutions.petcaresolutions.databinding.ActivityForgotBinding
import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class ForgotActivity : AppCompatActivity() {
    lateinit var binding: ActivityForgotBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityForgotBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.send.setOnClickListener {
            //temporario
            val intent = Intent(this, HomeActivity::class.java)
            startActivity(intent)
        }
    }
}